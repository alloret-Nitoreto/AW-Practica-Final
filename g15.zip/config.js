1
"use strict";
module.exports = {
    mysqlConfig: {
        host: "localhost",
        user: "root",
        password: "",
        database: "practicafinal"
    },
    port: 3000 // Puerto en el que escucha el servidor
}